1. Giải nén và bỏ tất cả vào folder target
2. Viết parser input vào file code.txt
3. Chạy file run.cmd và xem kết quả