1. Giải nén và bỏ tất cả vào folder target
2. Chạy file run.cmd
3. Nhập tên file input của parser (tên file là những file trong folder testcases: Ex: 201.txt hoặc 201)
4. Xem kết quả